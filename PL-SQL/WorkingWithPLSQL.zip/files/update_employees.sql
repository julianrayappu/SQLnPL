create or replace
PROCEDURE update_employees(id IN  EMPLOYEES.EMPLOYEE_ID%TYPE,percent IN  NUMBER)
IS
BEGIN
  UPDATE employees
  SET    salary = salary * (1 + percent/100)
  WHERE  employee_id = id;
  DBMS_OUTPUT.PUT_LINE('Salary incremented for employee_id:'||id);
  COMMIT;
END update_employees;


